﻿using Newtonsoft.Json;

namespace prototypepattern
{
    public interface  Person
    {
        public string Name { get; set; }
        public Person Clone(bool deepclone);
    }

    public class Manager : Person
    {
        public  string Name { get; set; }

        public Manager(string name)
        {
            Name = name;
        }

        public Person Clone(bool deepclone=false)
        {
            if (deepclone)
            {
                var jsonObject = JsonConvert.SerializeObject(this);
                return JsonConvert.DeserializeObject<Manager>(jsonObject);
            }
            return (Person)MemberwiseClone();
        }
    }

    public class Employee : Person
    {
        public string Name { get; set; }
        public Manager Manager { get; set; }
        public Employee(string name, Manager manager)
        {
            Name = name;
            Manager = manager;
        }
        public Person Clone(bool deepclone=false)
        {
            if (deepclone)
            {
                var jsonObject = JsonConvert.SerializeObject(this);
                return JsonConvert.DeserializeObject<Employee>(jsonObject);
            }
            return (Person)MemberwiseClone();
        }
    }
}
